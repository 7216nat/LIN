Se ha cogido el codigo de la practica de SSOO para realizar la parte //
opcional.
una vez instalado el modulo de chardev_fifo, hay que leer de (sudo dmseg | tail)//
los registros donde proporciona las informaciones de major y minor //
para llevar a cabo la accion de mknod.